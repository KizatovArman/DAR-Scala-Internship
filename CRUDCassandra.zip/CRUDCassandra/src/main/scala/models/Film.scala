package models

/**
  *
  * @param id
  * @param title
  * @param yearOfPublication
  */

case class Film(f_id: Int, f_title: String, year_of_publication: Int)
